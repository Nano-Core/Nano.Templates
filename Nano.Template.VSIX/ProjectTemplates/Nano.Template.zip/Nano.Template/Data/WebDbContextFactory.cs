using Nano.Data;
using Nano.Data.Providers.MySql;

namespace $safeprojectname$.Data
{
    /// <inheritdoc />
    public class WebDbContextFactory : BaseDbContextFactory<MySqlProvider, WebDbContext>
    {

    }
}
